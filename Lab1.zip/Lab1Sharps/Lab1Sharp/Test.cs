﻿using Lab1Wallet;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab1Sharp
{
    class Test
    {
        static void Main(string[] args)
        {
            Manager m1 = new Manager();
            m1.CreateUser(1, "f1", "l1", "e1");
            m1.CreateUser(2, "f2", "l2", "e2");
            m1.CreateUser(3, "f3", "l3", "e3");
            m1.CreateUser(4, "f4", "l4", "e4");
            m1.CreateUser(5, "f5", "l5", "e5");
            m1.CreateUser(6, "f6", "l6", "e6");
            m1.CreateWallet(1, 1, "w1", 1000);
            m1.CreateWallet(2, 2, "w2", 0);
            m1.CreateWallet(3, 3, "w3", -1000);
            m1.CreateWallet(4, 4, "w4", 34242);
            m1.CreateWallet(5, 5, "w5", 7777);
            m1.CreateWallet(6, 6, "w6", 4545);
            m1.CreateWallet(3, 7, "w7", 34535);
            m1.CreateWallet(2, 8, "w8", 2);
            m1.AddWalletUser(1, 2, 1);
            m1.AddWalletUser(2, 1, 2);
            m1.RemoveWalletUser(2, 1);
            for (int i = 1; i <= 6; i++)
            {
                Console.WriteLine(m1.GetWalletInfo(i));
            }
            m1.CreateTransaction(1, 1, 100500, new Category(1), new DateTime());
            m1.CreateTransaction(2, 2, -100500, new Category(2), new DateTime());
            m1.CreateTransaction(1, 3, 34243, new Category(3), new DateTime());
            m1.CreateTransaction(3, 4, 454, new Category(4), new DateTime());
            m1.CreateTransaction(5, 5, 0, new Category(5), new DateTime());
            m1.CreateTransaction(2, 6, 77, new Category(6), new DateTime());
            m1.CreateTransaction(3, 7, -999, new Category(7), new DateTime());
            m1.EditTransaction(2, -50250, new Category(8), new DateTime());
            m1.RemoveTransaction(3);
            for (int i = 1; i <= 8; i++) {
                Console.WriteLine(m1.GetWalletTransactions(i));
            }
            for (int i = 1; i <= 6; i++)
            {
                Console.WriteLine(m1.GetWalletInfo(i));
            }
            Console.ReadLine();
        }
    }
}
