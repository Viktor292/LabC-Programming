﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Collections;

namespace Lab1Wallet
{
    class Wallet
    {
        private int id;
        private string name;
        private int balance;
        private string moneytype;
        private string description;
        private int income = 0;
        private int costs = 0;
        private List<Transaction> trlist = new List<Transaction>();
        private List<Category> catlist = new List<Category>();
        private int idOwner;

        public Wallet(int id, int idOwner, string name, int balance, string moneytype = "USD", string description = "")
        {
            this.IdOwner = idOwner;
            this.id = id;
            this.name = name;
            this.balance = balance;
            this.moneytype = moneytype;
            this.description = description;
        }

        public Wallet(Wallet w)
        {
            this.id = w.id;
            this.name = w.name;
            this.balance = w.balance;
            this.moneytype = w.moneytype;
            this.description = w.description;
        }

        public int Id { get => id; set => id = value; }
        public string Name { get => name; set => name = value; }
        public int Balance { get => balance; set => balance = value; }
        public string Moneytype { get => moneytype; set => moneytype = value; }
        public string Description { get => description; set => description = value; }
        public List<Transaction> Trlist { get => trlist; set => trlist = value; }
        public List<Category> Catlist { get => catlist; set => catlist = value; }
        public int Income { get => income; set => income = value; }
        public int Costs { get => costs; set => costs = value; }
        public int IdOwner { get => idOwner; set => idOwner = value; }

        override
        public string ToString()
        {
            return id + " " + IdOwner + " " + name + " " + balance + " " + moneytype + " " + description + " " + income + " " + costs;
        }

        public string TransactionsToString()
        {
            String result = "";
            for(int i = trlist.Count - 1; i >= 0; i--)
            {
                if (trlist.Count - i >= 10) break;
                result += trlist[i].ToString() + "\r\n";
            }
            return result;
        }

        public string TransactionsToString(int start, int end)
        {
            if (end < 0) end = 0;
            if (start > trlist.Count) start = trlist.Count;
            String result = "";
            for (int i = start; i > 0 && i > end; i--)
            {
                if (trlist.Count - i >= 10) break;
                result += trlist[i].ToString() + "\r\n";
            }
            return result;
        }
    }
}
