﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Lab1Wallet
{
    class Transaction
    {
        private int id;
        private int sum;
        private string moneytype;
        private Category category;
        private string descr;
        private DateTime dateTr;

        public Transaction(int id, int sum, Category category, DateTime dateTr, string descr = "", string moneytype = "USD")
        {
            this.id = id;
            this.sum = sum;
            this.moneytype = moneytype;
            this.category = category;
            this.descr = descr;
            this.dateTr = dateTr;
        }

        public int Id { get => id; set => id = value; }
        public int Sum { get => sum; set => sum = value; }
        public string Moneytype { get => moneytype; set => moneytype = value; }
        public Category Category { get => category; set => category = value; }
        public string Descr { get => descr; set => descr = value; }
        public DateTime DateTr { get => dateTr; set => dateTr = value; }

        override
        public string ToString()
        {
            return id + " " + sum + " " + moneytype + " " + category.ToString() + " " + descr + " " + dateTr;
        }
    }
}
