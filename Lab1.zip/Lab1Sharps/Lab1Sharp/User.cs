﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Lab1Wallet
{
    class User
    {
        private int id;
        private string firstname;
        private string lastname;
        private string email;
        private List<Wallet> walletList = new List<Wallet>();
        private List<Category> categoryList = new List<Category>();

        public User(int id, string firstname, string lastname, string email)
        {
            this.id = id;
            this.firstname = firstname;
            this.lastname = lastname;
            this.email = email;
        }

        public Category FindCategory(int id)
        {
            for(int i = 0; i < categoryList.Count; i++)
            {
                if (categoryList[i].Id == id) return categoryList[i];
            }
            return null;
        }

        public void AddCategoryToWallet(int idWallet, int idCategory)
        {
            Category toAdd = FindCategory(idCategory);
            for(int i = 0; i < walletList.Count; i++)
            {
                if (walletList[i].Id == idWallet) walletList[i].Catlist.Add(toAdd);
            }
        }

        public void RemoveCategoryFromWallet(int idWallet, int idCategory)
        {
            for (int i = 0; i < walletList.Count; i++)
            {
                if (walletList[i].Id == idWallet)
                {
                    for (int j = 0; j < walletList[i].Catlist.Count; j++)
                    {
                        if (walletList[i].Catlist[j].Id == idCategory) walletList[i].Catlist.RemoveAt(j);
                    }
                }
            }
        }

        public int Id { get => id; set => id = value; }
        public string Firstname { get => firstname; set => firstname = value; }
        public string Lastname { get => lastname; set => lastname = value; }
        public string Email { get => email; set => email = value; }
        public List<Wallet> WalletList { get => walletList; set => walletList = value; }
        public List<Category> CategoryList { get => categoryList; set => categoryList = value; }
    }
}
