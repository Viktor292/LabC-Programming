﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Lab1Wallet
{
    class Category
    {
        private int id;
        private string name;
        private string descr;
        private string color;
        private string icon;

        public Category(int id, string name = "send", string descr = "", string color = "green", string icon = "")
        {
            this.id = id;
            this.name = name;
            this.descr = descr;
            this.color = color;
            this.icon = icon;
        }

        public string Name { get => name; set => name = value; }
        public string Descr { get => descr; set => descr = value; }
        public string Color { get => color; set => color = value; }
        public string Icon { get => icon; set => icon = value; }
        public int Id { get => id; set => id = value; }

        override
        public string ToString()
        {
            return name + " " + descr + " " + color + " " + icon;
        }
    }
}
