﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Lab1Wallet
{
    class Manager
    {
        List<User> userlist = new List<User>();

        //Створити користувача
        public void CreateUser(int id,  string firstname, string lastname, string email)
        {
            userlist.Add(new User(id, firstname, lastname, email));
        }

        //Отримати гаманець по його ід
        public Wallet GetWallet(int id)
        {
            for(int i = 0; i < userlist.Count; i++)
            {
                for (int j = 0; j < userlist[i].WalletList.Count; j++)
                {
                    if (userlist[i].WalletList[j].Id == id)
                    {
                        return new Wallet(userlist[i].WalletList[j]);
                    }
                }
            }
            return null;
        }

        //Створити гаманець
        public void CreateWallet(int userId, int id, string name, int balance, string moneytype = "USD", string description = "")
        {
            for (int i = 0; i < userlist.Count; i++)
            {
                if(userlist[i].Id == userId) userlist[i].WalletList.Add(new Wallet(id, userId, name, balance, moneytype, description));
            }
        }

        //видалити гаманець у користувача
        public void RemoveWalletUser(int idUser, int idWallet)
        {
            for (int i = 0; i < userlist.Count; i++)
            {
                if (idUser == userlist[i].Id) {
                    for (int j = 0; j < userlist[i].WalletList.Count; j++)
                    {
                        if (userlist[i].WalletList[j].Id == idWallet) userlist[i].WalletList.RemoveAt(j);
                    }
                }
            }
        }

        //надати доступ до гаманця користувачу
        public void AddWalletUser(int idOwner, int idUser, int idWallet)
        {
            for (int i = 0; i < userlist.Count; i++)
            {
                if (idUser == userlist[i].Id)
                {
                    for (int j = 0; j < userlist[i].WalletList.Count; j++)
                    {
                        if (userlist[i].WalletList[j].Id == idWallet && userlist[i].WalletList[j].IdOwner == idOwner) userlist[i].WalletList.Add(GetWallet(idWallet));
                    }
                }
            }
        }

        //створити транзакцію
        public void CreateTransaction(int idWallet, int id, int sum, Category category, DateTime dateTr, string moneytype = "USD")
        {
            for (int i = 0; i < userlist.Count; i++)
            {
                for (int j = 0; j < userlist[i].WalletList.Count; j++)
                {
                    if (userlist[i].WalletList[j].Id == idWallet)
                    {
                        if (sum < 0) userlist[i].WalletList[j].Costs += sum;
                        else userlist[i].WalletList[j].Income += sum;
                        userlist[i].WalletList[j].Balance += sum;
                        userlist[i].WalletList[j].Trlist.Add(new Transaction(id, sum, category, dateTr, moneytype));
                    }
                }
            }
        }

        //видалити транзакцію
        public void RemoveTransaction(int id)
        {
            for (int i = 0; i < userlist.Count; i++)
            {
                for (int j = 0; j < userlist[i].WalletList.Count; j++)
                {
                    for (int k = 0; k < userlist[i].WalletList[j].Trlist.Count; k++)
                    {
                        if (userlist[i].WalletList[j].Trlist[k].Id == id)
                        {
                            if (userlist[i].WalletList[j].Trlist[k].Sum < 0) userlist[i].WalletList[j].Costs -= userlist[i].WalletList[j].Trlist[k].Sum;
                            else userlist[i].WalletList[j].Income -= userlist[i].WalletList[j].Trlist[k].Sum;
                            userlist[i].WalletList[j].Balance -= userlist[i].WalletList[j].Trlist[k].Sum;
                            userlist[i].WalletList[j].Trlist.RemoveAt(k);
                        }
                    }
                }
            }
        }

        //редагувати транзакцію
        public void EditTransaction(int id, int sum, Category category, DateTime dateTr, string moneytype = "USD")
        {
            for (int i = 0; i < userlist.Count; i++)
            {
                for (int j = 0; j < userlist[i].WalletList.Count; j++)
                {
                    for (int k = 0; k < userlist[i].WalletList[j].Trlist.Count; k++)
                    {
                        if (userlist[i].WalletList[j].Trlist[k].Id == id)
                        {
                            if (userlist[i].WalletList[j].Trlist[k].Sum < 0) userlist[i].WalletList[j].Costs -= userlist[i].WalletList[j].Trlist[k].Sum;
                            else userlist[i].WalletList[j].Income -= userlist[i].WalletList[j].Trlist[k].Sum;
                            userlist[i].WalletList[j].Balance -= userlist[i].WalletList[j].Trlist[k].Sum;
                            userlist[i].WalletList[j].Trlist[k] = new Transaction(id, sum, category, dateTr, moneytype);
                            if (sum < 0) userlist[i].WalletList[j].Costs += sum;
                            else userlist[i].WalletList[j].Income += sum;
                            userlist[i].WalletList[j].Balance += sum;
                        }
                    }
                }
            }
        }

        //інформація по гаманцю у форматі id + " " + name + " " + balance + " " + moneytype + " " + description + " " + income + " " + costs;
        public String GetWalletInfo(int id)
        {
            for (int i = 0; i < userlist.Count; i++)
            {
                for (int j = 0; j < userlist[i].WalletList.Count; j++)
                {
                    if (userlist[i].WalletList[j].Id == id)
                    {
                        return userlist[i].WalletList[j].ToString();
                    }
                }
            }
            return null;
        }

        //десять останніх транзакцій гаманця
        public String GetWalletTransactions(int id)
        {
            for (int i = 0; i < userlist.Count; i++)
            {
                for (int j = 0; j < userlist[i].WalletList.Count; j++)
                {
                    if (userlist[i].WalletList[j].Id == id)
                    {
                        return userlist[i].WalletList[j].TransactionsToString();
                    }
                }
            }
            return null;
        }

        //транзакції гаманця з а по б
        public String GetWalletTransactions(int id, int start, int end)
        {
            for (int i = 0; i < userlist.Count; i++)
            {
                for (int j = 0; j < userlist[i].WalletList.Count; j++)
                {
                    if (userlist[i].WalletList[j].Id == id)
                    {
                        return userlist[i].WalletList[j].TransactionsToString(start, end);
                    }
                }
            }
            return null;
        }

        //додати категорію користувачу
        public void AddCategory(int idUser, int id, string name = "send", string descr = "", string color = "green", string icon = "")
        {
            for (int i = 0; i < userlist.Count; i++)
            {
                if (idUser == userlist[i].Id)
                {
                    userlist[i].CategoryList.Add(new Category(id, name, descr, color, icon));
                }
            }
        }

        //видалити категорію у користувача
        public void RemoveCategory(int idUser, int idCat)
        {
            for (int i = 0; i < userlist.Count; i++)
            {
                if (idUser == userlist[i].Id)
                {
                    for (int j = 0; j < userlist[i].CategoryList.Count; j++)
                    {
                        if (userlist[i].CategoryList[j].Id == idCat) userlist[i].CategoryList.RemoveAt(j);
                    }
                }
            }
        }

        //редагувати категорію у користувача
        public void EditCategory(int idUser, int idCat, int id, string name = "send", string descr = "", string color = "green", string icon = "")
        {
            for (int i = 0; i < userlist.Count; i++)
            {
                if (idUser == userlist[i].Id)
                {
                    for (int j = 0; j < userlist[i].CategoryList.Count; j++)
                    {
                        if (userlist[i].CategoryList[j].Id == idCat) userlist[i].CategoryList[j] = new Category(id, name, descr, color, icon);
                    }
                }
            }
        }
    }

}
